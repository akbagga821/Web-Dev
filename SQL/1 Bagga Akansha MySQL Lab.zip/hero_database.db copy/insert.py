import sqlite3

connection = sqlite3.connect('hero_database.db')
connection2 = sqlite3.connect('equipment_database.db')
connection3 = sqlite3.connect('quests_database.db')

with open('insert.sql') as f:
    connection.executescript(f.read())

with open('insert_equipment.sql') as f:
    connection.executescript(f.read())

with open('insert_quests.sql') as f:
    connection.executescript(f.read())